## Contributing to greed

I passed my final exam with full marks (100L/100) in 2018 :D

I'm now allowed to accept contributions here!

Please submit bugs and feature requests as [issues](https://github.com/Steffo99/greed/issues), and submit 
improvements as [pull requests](https://github.com/Steffo99/greed/pulls), or, if your country 
[cannot access GitHub](https://help.github.com/en/github/site-policy/github-and-trade-controls), please submit issues 
in the [Telegram group](https://t.me/greed_project) and send me [git patches](https://git-scm.com/docs/git-format-patch)
 via email at [ste.pigozzi+patch@gmail.com](mailto:ste.pigozzi+patch@gmail.com).

Avoid contacting me on other social media sites, as I rarely use them and may not see your message.
