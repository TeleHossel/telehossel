# Localized strings

This folder contains Python modules for every language Greed is localized in.

Filenames should use the [IETF language tag](https://en.wikipedia.org/wiki/IETF_language_tag) of the language they describe.

The dash `-` should be replaced with an underscore `_`.
